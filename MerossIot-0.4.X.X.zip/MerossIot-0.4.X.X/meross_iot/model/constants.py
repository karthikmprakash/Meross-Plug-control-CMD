LONG_TIMEOUT = 30.0   # For wifi scan
SHORT_TIMEOUT = 10.0   # For any other command


