MerossManager
-------------

.. automodule:: meross_iot.manager
   :members:
