ElectricityMixin
----------------

.. autoclass:: meross_iot.controller.mixins.electricity.ElectricityMixin
   :members:
