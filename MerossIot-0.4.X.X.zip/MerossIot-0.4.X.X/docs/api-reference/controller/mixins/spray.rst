SprayMixin
----------

.. autoclass:: meross_iot.controller.mixins.spray.SprayMixin
   :members:
