Ms100Sensor
-----------

.. autoclass:: meross_iot.controller.subdevice.Ms100Sensor
   :members:
